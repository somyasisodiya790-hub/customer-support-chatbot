# Automated Customer Support Chatbot

An AI-powered customer support chatbot that automatically answers FAQs and handles complex questions using OpenAI's GPT API.

## 🚀 Features
- Answers predefined FAQs instantly
- Uses AI fallback for unseen questions
- Logs all interactions
- Simple web API using Flask

## ⚡ How to Run

1. Clone the repository:
```bash
git clone https://github.com/your-username/customer-support-chatbot.git
cd customer-support-chatbot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Add your OpenAI API key to `.env` file.

4. Start the chatbot server:
```bash
python app.py
```

5. Send a POST request to test:
```bash
curl -X POST http://127.0.0.1:5000/chat \
-H "Content-Type: application/json" \
-d '{"question": "What is your refund policy?"}'
```

## ✅ Why This Project Stands Out
- Demonstrates automation of repetitive customer support tasks
- Replaces multiple support reps with a scalable solution
- Uses AI to improve over time

---
Made by [Your Name]