import openai
import pandas as pd
import csv
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')

faq_df = pd.read_csv('faq_dataset.csv')

def find_answer_from_faq(user_question):
    for index, row in faq_df.iterrows():
        if row['Question'].lower() in user_question.lower():
            return row['Answer']
    return None

def get_ai_response(user_question):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful customer support chatbot."},
                {"role": "user", "content": user_question}
            ],
            max_tokens=150,
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        return "Sorry, I am unable to answer right now."

def chatbot_response(user_question):
    answer = find_answer_from_faq(user_question)
    if answer:
        return answer
    else:
        return get_ai_response(user_question)

def log_chat(user_question, bot_response):
    with open('chat_logs.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now(), user_question, bot_response])